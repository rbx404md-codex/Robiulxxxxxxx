#!/data/data/com.termux/files/usr/bin/bash
G='\033[0;32m' Y='\033[1;33m' R='\033[0;31m' N='\033[0m'
echo -e "${G}╔══════════════════════════════╗"
echo "║   RBX HUB — TERMUX INSTALLER ║"
echo -e "╚══════════════════════════════╝${N}"
echo -e "${Y}[1/5] Installing packages...${N}"
pkg update -y && pkg install -y php mariadb
echo -e "${Y}[2/5] Starting MySQL...${N}"
mysqld_safe & sleep 3
echo -e "${Y}[3/5] Setting up .env...${N}"
[ ! -f .env ] && cp .env.example .env && echo -e "${G}  ✅ .env created${N}"
echo -e "${Y}[4/5] Importing database...${N}"
mysql -u root < database.sql && echo -e "${G}  ✅ Database imported${N}" || echo -e "${R}  ❌ DB import failed${N}"
echo -e "${Y}[5/5] Starting server...${N}"
echo ""
echo -e "${G}╔══════════════════════════════════╗"
echo "║  🚀 RBX Hub is ready!            ║"
echo "║                                  ║"
echo "║  🌐 http://localhost:8080         ║"
echo "║  🔧 http://localhost:8080/admin/setup.php ║"
echo -e "╚══════════════════════════════════╝${N}"
php -S 0.0.0.0:8080
