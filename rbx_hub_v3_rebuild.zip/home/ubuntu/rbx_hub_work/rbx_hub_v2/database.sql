CREATE DATABASE IF NOT EXISTS rbx_hub DEFAULT CHARACTER SET utf8mb4 DEFAULT COLLATE utf8mb4_unicode_ci;
USE rbx_hub;

CREATE TABLE IF NOT EXISTS admins (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100),
  role ENUM('SUPER_ADMIN','ADMIN','RESELLER') DEFAULT 'ADMIN',
  status ENUM('ACTIVE','BANNED') DEFAULT 'ACTIVE',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100),
  hwid VARCHAR(255),
  access_type ENUM('BASIC','PRO','ENTERPRISE') DEFAULT 'BASIC',
  status ENUM('ACTIVE','BANNED','EXPIRED') DEFAULT 'ACTIVE',
  expiry_date DATETIME,
  created_by VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME,
  last_ip VARCHAR(45),
  INDEX idx_username (username),
  INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS licenses (
  id INT PRIMARY KEY AUTO_INCREMENT,
  license_key VARCHAR(120) UNIQUE NOT NULL,
  access_type ENUM('BASIC','PRO','ENTERPRISE') NOT NULL,
  duration_days INT NOT NULL,
  price DECIMAL(10,2) DEFAULT 0,
  reseller_price DECIMAL(10,2) DEFAULT 0,
  status ENUM('UNUSED','USED','REVOKED','EXPIRED') DEFAULT 'UNUSED',
  used_by VARCHAR(50),
  used_hwid VARCHAR(255),
  created_by VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME,
  revoked_at DATETIME,
  INDEX idx_key (license_key),
  INDEX idx_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  product_name VARCHAR(100),
  access_type ENUM('BASIC','PRO','ENTERPRISE'),
  duration_days INT,
  price DECIMAL(10,2),
  reseller_price DECIMAL(10,2),
  features TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  sort_order INT DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS downloads (
  id INT PRIMARY KEY AUTO_INCREMENT,
  tool_name VARCHAR(100) NOT NULL,
  version VARCHAR(20) NOT NULL,
  description TEXT,
  access_type ENUM('BASIC','PRO','ENTERPRISE') DEFAULT 'BASIC',
  download_url TEXT,
  mandatory_update TINYINT(1) DEFAULT 0,
  download_count INT DEFAULT 0,
  is_active BOOLEAN DEFAULT TRUE,
  created_by VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS announcements (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(200) NOT NULL,
  content TEXT NOT NULL,
  type ENUM('info','warning','success','danger') DEFAULT 'info',
  is_active BOOLEAN DEFAULT TRUE,
  created_by VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS activity_logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50),
  admin_name VARCHAR(50),
  action VARCHAR(100),
  details TEXT,
  hwid VARCHAR(255),
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_username (username),
  INDEX idx_action (action),
  INDEX idx_date (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
  id INT PRIMARY KEY AUTO_INCREMENT,
  setting_key VARCHAR(100) UNIQUE,
  setting_value TEXT,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO settings (setting_key,setting_value) VALUES
('site_name',        'RBX Hub'),
('api_key',          'CHANGE-THIS-FROM-ADMIN-SETTINGS'),
('currency',         'BDT'),
('telegram_channel', 'https://t.me/SkillShareBD77'),
('contact_admin',    '@rbx404'),
('maintenance_mode', 'false');

INSERT IGNORE INTO products (product_name,access_type,duration_days,price,reseller_price,features,sort_order) VALUES
('RBX Basic 5 Days',    'BASIC',     5,    50,  35,  '5 Days + Basic Tools', 1),
('RBX Basic 9 Days',    'BASIC',     9,    80,  55,  '9 Days + Basic Tools', 2),
('RBX Pro Monthly',     'PRO',       30,   180, 120, '30 Days + All Tools',  3),
('RBX Pro Lifetime',    'PRO',       36500,300, 200, 'Lifetime + All Tools', 4),
('RBX Enterprise',      'ENTERPRISE',36500,500, 350, 'Lifetime + VIP',       5);
