<?php
require_once 'config.php';

$action = $_REQUEST['action'] ?? '';

// Public endpoints (no auth needed)
if ($action === 'stats') {
    header('Content-Type: application/json');
    echo json_encode([
        'total_users'     => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM users"))['c']??0),
        'active_users'    => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM users WHERE status='ACTIVE'"))['c']??0),
        'total_licenses'  => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM licenses"))['c']??0),
        'active_licenses' => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM licenses WHERE status='USED'"))['c']??0),
        'total_logs'      => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM activity_logs"))['c']??0),
        'total_downloads' => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COALESCE(SUM(download_count),0) c FROM downloads"))['c']??0),
        'total_tools'     => (int)(mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM downloads WHERE is_active=1"))['c']??0),
    ]);
    exit();
}

if ($action === 'pricing') {
    header('Content-Type: application/json');
    $prices = [];
    $res = mysqli_query($conn,"SELECT access_type, MIN(price) p FROM products WHERE is_active=1 GROUP BY access_type");
    while ($r = mysqli_fetch_assoc($res)) $prices[strtolower($r['access_type'])] = (int)$r['p'];
    echo json_encode($prices);
    exit();
}

// Protected API - requires API key
header('Content-Type: text/plain; charset=utf-8');

// Rate limit API calls
if (!rate_limit_check('api_call', 30, 60)) {
    http_response_code(429); die('RATE_LIMITED');
}

$api_key   = trim($_POST['api_key'] ?? $_GET['api_key'] ?? '');
$valid_key = get_setting('api_key', '');
if (empty($valid_key) || !hash_equals($valid_key, $api_key)) {
    http_response_code(401);
    log_activity('', 'API_INVALID_KEY', 'IP: '.get_ip());
    die('INVALID_API_KEY');
}

switch ($action) {

    case 'login':
        $u    = clean_post('username');
        $p    = $_POST['password'] ?? '';
        $hwid = clean_post('hwid', '', 128);

        if (!$u || !$p) { die('MISSING_FIELDS'); }

        $stmt = mysqli_prepare($conn,"SELECT * FROM users WHERE username=?");
        mysqli_stmt_bind_param($stmt,'s',$u); mysqli_stmt_execute($stmt);
        $user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)); mysqli_stmt_close($stmt);

        if (!$user || !password_verify($p, $user['password'])) {
            log_activity($u,'LOGIN_FAILED','',$hwid); die('INVALID_CREDENTIALS');
        }
        if ($user['status']==='BANNED')  { log_activity($u,'LOGIN_BANNED','',$hwid);  die('ACCOUNT_BANNED'); }
        if ($user['expiry_date'] && strtotime($user['expiry_date'])<time()) {
            log_activity($u,'LOGIN_EXPIRED','',$hwid); die('ACCOUNT_EXPIRED');
        }
        if ($user['hwid'] && $user['hwid'] !== $hwid) {
            log_activity($u,'HWID_MISMATCH',"stored={$user['hwid']}",$hwid); die('HWID_MISMATCH');
        }
        $ip = get_ip();
        $s2 = mysqli_prepare($conn,"UPDATE users SET hwid=?,last_login=NOW(),last_ip=? WHERE username=?");
        mysqli_stmt_bind_param($s2,'sss',$hwid,$ip,$u); mysqli_stmt_execute($s2); mysqli_stmt_close($s2);
        log_activity($u,'LOGIN_SUCCESS','',$hwid);
        echo 'LOGIN_SUCCESS|'.$user['access_type'];
        break;

    case 'redeem_key':
        $u    = clean_post('username');
        $p    = $_POST['password'] ?? '';
        $key  = clean_post('key','',60);
        $hwid = clean_post('hwid','',128);

        $stmt = mysqli_prepare($conn,"SELECT * FROM licenses WHERE license_key=? AND status='UNUSED'");
        mysqli_stmt_bind_param($stmt,'s',$key); mysqli_stmt_execute($stmt);
        $lic  = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)); mysqli_stmt_close($stmt);
        if (!$lic) { log_activity($u,'REDEEM_FAILED',"Key:$key",$hwid); die('INVALID_KEY'); }

        $expiry = date('Y-m-d H:i:s', time()+($lic['duration_days']*86400));
        $hp     = password_hash($p, PASSWORD_DEFAULT);
        $plan   = $lic['access_type'];
        $ip     = get_ip();

        $stmt2 = mysqli_prepare($conn,"SELECT id FROM users WHERE username=?");
        mysqli_stmt_bind_param($stmt2,'s',$u); mysqli_stmt_execute($stmt2);
        $exists = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt2)); mysqli_stmt_close($stmt2);

        if ($exists) {
            $s = mysqli_prepare($conn,"UPDATE users SET password=?,hwid=?,expiry_date=?,access_type=?,status='ACTIVE',last_ip=? WHERE username=?");
            mysqli_stmt_bind_param($s,'ssssss',$hp,$hwid,$expiry,$plan,$ip,$u);
        } else {
            $s = mysqli_prepare($conn,"INSERT INTO users (username,password,hwid,expiry_date,access_type,last_ip) VALUES (?,?,?,?,?,?)");
            mysqli_stmt_bind_param($s,'ssssss',$u,$hp,$hwid,$expiry,$plan,$ip);
        }
        mysqli_stmt_execute($s); mysqli_stmt_close($s);
        $s2 = mysqli_prepare($conn,"UPDATE licenses SET status='USED',used_by=?,used_hwid=?,expires_at=? WHERE license_key=?");
        mysqli_stmt_bind_param($s2,'ssss',$u,$hwid,$expiry,$key); mysqli_stmt_execute($s2); mysqli_stmt_close($s2);
        log_activity($u,'REDEEM_SUCCESS',"Key:$key Plan:$plan",$hwid);
        echo 'REDEEM_SUCCESS|'.$plan;
        break;

    default:
        http_response_code(400); die('INVALID_ACTION');
}
