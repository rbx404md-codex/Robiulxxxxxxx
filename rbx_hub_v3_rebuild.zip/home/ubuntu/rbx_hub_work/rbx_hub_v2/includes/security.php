<?php
declare(strict_types=1);
// includes/security.php — Centralized Security Layer

/* ===================== CSRF ===================== */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="'.csrf_token().'">';
}

function csrf_verify(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(403);
        die('<h2 style="font-family:monospace;color:#ef4444;text-align:center;padding:60px">
             ❌ 403 — CSRF validation failed. <a href="javascript:history.back()">Go back</a></h2>');
    }
}

/* ===================== RATE LIMITING ===================== */
// Session rate limiting works on shared hosting, but it is per PHP session.
// For multi-server or bot-heavy installs, persist counters in MySQL/Redis.
function rate_limit_check(string $key, int $max = 5, int $window = 900): bool {
    $ip      = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $rk      = "rl_{$key}_{$ip}";
    $now     = time();
    $blocked = "blk_{$key}_{$ip}";

    // Check if blocked
    if (!empty($_SESSION[$blocked]) && $_SESSION[$blocked] > $now) {
        $wait = ceil(($_SESSION[$blocked] - $now) / 60);
        http_response_code(429);
        die('<div style="font-family:monospace;color:#ef4444;text-align:center;padding:80px;background:#05050a;min-height:100vh">
         <h2>⛔ Too Many Attempts</h2>
         <p style="color:#5a5a7a;margin-top:12px">Please wait <strong style="color:#f59e0b">'.$wait.' minute(s)</strong> before trying again.</p>
         </div>');
    }

    if (empty($_SESSION[$rk])) {
        $_SESSION[$rk] = ['count' => 0, 'start' => $now];
    }

    // Reset window
    if ($now - $_SESSION[$rk]['start'] > $window) {
        $_SESSION[$rk] = ['count' => 0, 'start' => $now];
    }

    $_SESSION[$rk]['count']++;

    if ($_SESSION[$rk]['count'] > $max) {
        $_SESSION[$blocked] = $now + $window;
        unset($_SESSION[$rk]);
        return false; // blocked
    }
    return true;
}

function rate_limit_reset(string $key): void {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    unset($_SESSION["rl_{$key}_{$ip}"]);
    unset($_SESSION["blk_{$key}_{$ip}"]);
}

/* ===================== INPUT SANITIZATION ===================== */
function clean(string $input, int $maxlen = 255): string {
    return htmlspecialchars(trim(substr($input, 0, $maxlen)), ENT_QUOTES, 'UTF-8');
}

function clean_post(string $key, string $default = '', int $maxlen = 255): string {
    return clean($_POST[$key] ?? $default, $maxlen);
}

function clean_get(string $key, string $default = ''): string {
    return clean($_GET[$key] ?? $default);
}

function validate_username(string $u): bool {
    return strlen($u) >= 4 && strlen($u) <= 50 && preg_match('/^[a-zA-Z0-9_]+$/', $u);
}

function validate_password(string $p): bool {
    return strlen($p) >= 6 && strlen($p) <= 100;
}

function validate_license_key(string $k): bool {
    return (bool)preg_match('/^RBX-[A-Z]+-[A-Z0-9]+-[A-Z0-9]+-[a-z0-9]+$/', $k);
}

/* ===================== SESSION SECURITY ===================== */
function secure_session_start(): void {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.cookie_httponly', '1');
        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_samesite', 'Strict');
        session_start();
    }
}

function session_regenerate(): void {
    session_regenerate_id(true);
}

/* ===================== MAINTENANCE MODE ===================== */
function check_maintenance(): void {
    global $conn;
    if (!$conn) return;
    $r = mysqli_fetch_assoc(mysqli_query($conn,
        "SELECT setting_value FROM settings WHERE setting_key='maintenance_mode'"));
    if (($r['setting_value'] ?? 'false') === 'true') {
        // Admins bypass maintenance
        if (!empty($_SESSION['admin_id'])) return;
        http_response_code(503);
        die('<!DOCTYPE html><html><head><title>Maintenance</title>
        <style>*{margin:0;padding:0;box-sizing:border-box}body{background:#05050a;display:flex;
        align-items:center;justify-content:center;min-height:100vh;font-family:monospace}
        .box{text-align:center;color:#e0e0f0}.ico{font-size:64px;margin-bottom:20px}
        h1{font-size:28px;color:#f59e0b;margin-bottom:10px}
        p{color:#5a5a7a;font-size:15px}</style></head>
        <body><div class="box"><div class="ico">🔧</div>
        <h1>Under Maintenance</h1>
        <p>We\'ll be back shortly. Follow <a href="https://t.me/SkillShareBD77"
           style="color:#7c3aed;text-decoration:none">t.me/SkillShareBD77</a> for updates.</p>
        </div></body></html>');
    }
}

/* ===================== SECURITY HEADERS ===================== */
function set_security_headers(): void {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://api.fontshare.com https://fonts.googleapis.com; font-src 'self' https://api.fontshare.com https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'");
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') { header('Strict-Transport-Security: max-age=31536000; includeSubDomains'); }
    header('Permissions-Policy: geolocation=(), camera=(), microphone=()');
}
