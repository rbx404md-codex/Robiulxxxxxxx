<?php
declare(strict_types=1);
// Output buffering keeps redirects and security headers reliable.
if (!ob_get_level()) { ob_start(); }
// .env loader runs below; use getenv here so timezone can be set early.
date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'Asia/Dhaka');

// Security headers first
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://api.fontshare.com https://fonts.googleapis.com; font-src 'self' https://api.fontshare.com https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'");
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') { header('Strict-Transport-Security: max-age=31536000; includeSubDomains'); }
header('Permissions-Policy: geolocation=(), camera=(), microphone=()');

// Secure session
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    session_start();
}

// .env loader
function load_env(string $path): void {
    if (!file_exists($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        [$k, $v] = array_map('trim', explode('=', $line, 2));
        if ($k) $_ENV[$k] = $v;
    }
}
load_env(__DIR__ . '/.env');

define('DB_HOST',  $_ENV['DB_HOST']  ?? '127.0.0.1');
define('DB_USER',  $_ENV['DB_USER']  ?? 'root');
define('DB_PASS',  $_ENV['DB_PASS']  ?? '');
define('DB_NAME',  $_ENV['DB_NAME']  ?? 'rbx_hub');
define('APP_NAME', $_ENV['APP_NAME'] ?? 'RBX Hub');
define('APP_URL',  $_ENV['APP_URL']  ?? 'http://localhost:8080');
define('APP_VER',  '2.1.0');

// DB
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) { http_response_code(500); die('DB Error'); }
mysqli_set_charset($conn, 'utf8mb4');

// Load security helpers
require_once __DIR__ . '/includes/security.php';

// Check maintenance (skip for admin)
if (!str_contains($_SERVER['REQUEST_URI'] ?? '', '/admin/')) {
    check_maintenance();
}

// Auth
function is_admin(): bool    { return isset($_SESSION['admin_id']); }
function is_super(): bool    { return is_admin() && ($_SESSION['admin_role'] ?? '') === 'SUPER_ADMIN'; }
function is_super_admin(): bool { return is_super(); }
function is_reseller(): bool { return is_admin() && ($_SESSION['admin_role'] ?? '') === 'RESELLER'; }
function is_user(): bool     { return isset($_SESSION['user_id']); }

function redirect(string $url): never { header("Location: $url"); exit(); }
function h(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

function get_ip(): string {
    return $_SERVER['HTTP_CF_CONNECTING_IP']
        ?? $_SERVER['HTTP_X_FORWARDED_FOR']
        ?? $_SERVER['REMOTE_ADDR'] ?? '';
}

// Logging
function log_activity(string $user, string $action, string $details = '', string $hwid = ''): void {
    global $conn;
    $admin = $_SESSION['admin_username'] ?? $_SESSION['user_username'] ?? '';
    $ip = get_ip(); $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $stmt = mysqli_prepare($conn,
        "INSERT INTO activity_logs (username,admin_name,action,details,hwid,ip_address,user_agent)
         VALUES (?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt,'sssssss',$user,$admin,$action,$details,$hwid,$ip,$ua);
    mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
}

// License generator
function generate_license(string $type = 'PRO'): string {
    $tier = match($type) { 'ENTERPRISE'=>'ENTERPRISE','PRO'=>'PRO','BASIC'=>'BASIC', default=>'BASIC' };
    $rand = strtoupper(bin2hex(random_bytes(9)));
    return "RBX-$tier-".substr($rand,0,6)."-".substr($rand,6,6)."-".substr($rand,12,6);
}
function generate_license_key(string $type = 'PRO'): string { return generate_license($type); }

function fmt_date(?string $d): string {
    if (!$d || $d === '0000-00-00 00:00:00') return '—';
    return date('d M Y, h:i A', strtotime($d));
}

function time_left(?string $exp): string {
    if (!$exp) return '—';
    $diff = strtotime($exp) - time();
    if ($diff < 0) return '<span style="color:#ef4444">Expired</span>';
    $d = floor($diff/86400); $h = floor(($diff%86400)/3600);
    return "{$d}d {$h}h";
}

function get_setting(string $key, string $default = ''): string {
    global $conn;
    $stmt = mysqli_prepare($conn, 'SELECT setting_value FROM settings WHERE setting_key=?');
    mysqli_stmt_bind_param($stmt, 's', $key);
    mysqli_stmt_execute($stmt);
    $r = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
    return $r['setting_value'] ?? $default;
}
