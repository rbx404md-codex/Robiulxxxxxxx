<?php
require_once '../config.php';
if (!is_user()) redirect('../user/login.php');
$uid = $_SESSION['user_id'];
$u   = mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM users WHERE id=".intval($uid)));
$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (isset($_POST['change_password'])) {
        $old = $_POST['old_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $con = $_POST['confirm_password'] ?? '';
        if (!password_verify($old, $u['password'])) { $err = 'Current password is wrong.'; }
        elseif (!validate_password($new)) { $err = 'New password: 6-100 characters.'; }
        elseif ($new !== $con) { $err = 'Passwords do not match.'; }
        else {
            $hp   = password_hash($new, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conn,"UPDATE users SET password=? WHERE id=?");
            mysqli_stmt_bind_param($stmt,'si',$hp,$uid);
            mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
            log_activity($u['username'],'PASSWORD_CHANGED','Password updated');
            $msg = '✅ Password changed successfully!';
        }
    }
    if (isset($_POST['reset_hwid'])) {
        $stmt = mysqli_prepare($conn,"UPDATE users SET hwid=NULL WHERE id=?");
        mysqli_stmt_bind_param($stmt,'i',$uid);
        mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
        log_activity($u['username'],'HWID_RESET_SELF','HWID reset by user');
        $msg = '✅ HWID reset! Will re-bind on next tool run.';
        $u['hwid'] = null;
    }
}
?><!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Settings — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head><body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar"><div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">User Portal / Account</div><div class="tb-title">Settings</div></div></div><div class="tb-right"><span class="tb-clock" id="clock"></span><span class="online-dot"></span></div></div>
  <div class="content">
    <?php if($msg): ?><div class="alert alert-ok fade-in"><?= h($msg) ?></div><?php endif; ?>
    <?php if($err): ?><div class="alert alert-err fade-in">⚠️ <?= h($err) ?></div><?php endif; ?>
    <div class="grid-2">

      <div class="card fade-in">
        <div class="card-hdr"><span class="card-title">🔑 Change Password</span></div>
        <div class="card-body">
          <form method="POST">
            <?= csrf_field() ?>
            <div class="form-group" style="margin-bottom:12px"><label>Current Password</label>
              <input type="password" name="old_password" required></div>
            <div class="form-group" style="margin-bottom:12px"><label>New Password</label>
              <input type="password" name="new_password" minlength="6" required></div>
            <div class="form-group" style="margin-bottom:18px"><label>Confirm New Password</label>
              <input type="password" name="confirm_password" required></div>
            <button type="submit" name="change_password" class="btn btn-grad" style="border:none;cursor:pointer">
              🔑 Update Password
            </button>
          </form>
        </div>
      </div>

      <div class="card fade-in">
        <div class="card-hdr"><span class="card-title">📱 Device Management</span></div>
        <div class="card-body">
          <div style="padding:16px;background:rgba(255,255,255,.02);border:1px solid var(--border);border-radius:8px;margin-bottom:16px">
            <div style="font-size:11px;color:var(--muted);text-transform:uppercase;letter-spacing:1px;margin-bottom:8px">Bound Device (HWID)</div>
            <div style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--cyan);word-break:break-all">
              <?= $u['hwid'] ? h($u['hwid']) : '<span style="color:var(--muted)">Not bound yet</span>' ?>
            </div>
          </div>
          <div class="alert alert-warn" style="font-size:12px;margin-bottom:16px">
            ⚠️ Resetting HWID will log you out from your tool. Re-run the tool to re-bind.
          </div>
          <form method="POST">
            <?= csrf_field() ?>
            <button type="submit" name="reset_hwid" class="btn btn-outline"
              onclick="return confirm('Reset your device binding?')">
              🔄 Reset HWID
            </button>
          </form>
        </div>
      </div>

      <div class="card fade-in">
        <div class="card-hdr"><span class="card-title">👤 Account Info</span></div>
        <div class="card-body">
          <?php $info=[
            ['Username', $u['username'],'text'],
            ['Plan', $u['access_type'],'badge'],
            ['Status', $u['status'],'badge'],
            ['Member Since', fmt_date($u['created_at']),'text'],
            ['Last Login', fmt_date($u['last_login']),'text'],
            ['Last IP', $u['last_ip']??'—','mono'],
          ]; foreach($info as [$lbl,$val,$type]): ?>
          <div style="display:flex;justify-content:space-between;align-items:center;
                      padding:10px 0;border-bottom:1px solid var(--border)">
            <span style="font-size:12px;color:var(--muted)"><?= $lbl ?></span>
            <?php if($type==='badge'): ?>
              <span class="badge b-<?= strtolower($val) ?>"><?= h($val) ?></span>
            <?php elseif($type==='mono'): ?>
              <span style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--cyan)"><?= h($val) ?></span>
            <?php else: ?>
              <span style="font-size:13px;font-weight:500"><?= h($val) ?></span>
            <?php endif; ?>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div class="card fade-in">
        <div class="card-hdr"><span class="card-title">🔗 Support</span></div>
        <div class="card-body">
          <p style="font-size:13px;color:var(--muted);margin-bottom:16px">
            Need help? Contact admin on Telegram.
          </p>
          <a href="<?= h(get_setting('telegram_channel','#')) ?>" target="_blank" class="btn btn-outline" style="margin-bottom:10px">
            📢 Join Telegram Channel
          </a><br>
          <a href="https://t.me/<?= ltrim(h(get_setting('contact_admin','rbx404')),'@') ?>" target="_blank" class="btn btn-outline">
            💬 Contact Admin
          </a>
        </div>
      </div>

    </div>
  </div>
</div></div>
<script src="../assets/script.js"></script>
</body></html>
