<?php
require_once '../config.php';
if (!is_user()) redirect('../user/login.php');
$uid  = $_SESSION['user_id'];
$plan = $_SESSION['user_plan'] ?? 'BASIC';
$order = ['BASIC'=>0,'PRO'=>1,'ENTERPRISE'=>2];
$my_level = $order[$plan] ?? 0;
// Increment download count
if (isset($_GET['dl'])) {
    $did = (int)$_GET['dl'];
    $st=mysqli_prepare($conn,"SELECT * FROM downloads WHERE id=? AND is_active=1"); mysqli_stmt_bind_param($st,'i',$did); mysqli_stmt_execute($st); $tool=mysqli_fetch_assoc(mysqli_stmt_get_result($st)); mysqli_stmt_close($st);
    if ($tool) {
        $t_level = $order[$tool['access_type']] ?? 0;
        if ($my_level >= $t_level) {
            $up=mysqli_prepare($conn,"UPDATE downloads SET download_count=download_count+1 WHERE id=?"); mysqli_stmt_bind_param($up,'i',$did); mysqli_stmt_execute($up); mysqli_stmt_close($up);
            log_activity($_SESSION['user_username'],'DOWNLOAD',$tool['tool_name'].' v'.$tool['version']);
            if ($tool['download_url']) {
                header("Location: ".$tool['download_url']); exit();
            }
        }
    }
    redirect('downloads.php');
}
$tools = mysqli_query($conn,"SELECT * FROM downloads WHERE is_active=1 ORDER BY created_at DESC");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Downloads — <?= htmlspecialchars(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head><body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar"><div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">User Portal / Tools</div><div class="tb-title">Downloads</div></div></div><div class="tb-right"><span class="tb-clock" id="clock"></span><span class="online-dot"></span></div></div>
  <div class="content">
    <div class="download-grid">
    <?php if(mysqli_num_rows($tools)): while($t=mysqli_fetch_assoc($tools)):
      $t_level = $order[$t['access_type']] ?? 0;
      $can_dl  = $my_level >= $t_level; ?>
    <div class="card fade-in" style="<?= !$can_dl?'opacity:.6':'' ?>">
      <div class="card-body">
        <?php if($t['mandatory_update']): ?><div class="alert alert-warn" style="margin-bottom:12px;padding:8px 12px;font-size:12px">⚠️ Mandatory Update</div><?php endif; ?>
        <div style="font-size:18px;font-weight:700;margin-bottom:4px"><?= htmlspecialchars($t['tool_name']) ?></div>
        <div style="display:flex;gap:8px;margin-bottom:10px">
          <span class="badge b-<?= strtolower($t['access_type']) ?>"><?= htmlspecialchars($t['access_type']) ?></span>
          <span style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--a2);padding:3px 8px;background:rgba(6,182,212,.1);border-radius:4px">v<?= htmlspecialchars($t['version']) ?></span>
        </div>
        <div style="font-size:13px;color:var(--muted);margin-bottom:16px"><?= htmlspecialchars($t['description']) ?></div>
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:12px;color:var(--muted)">⬇️ <?= $t['download_count'] ?> downloads</span>
          <?php if($can_dl): ?>
          <a href="downloads.php?dl=<?= $t['id'] ?>" class="btn btn-grad btn-sm">📥 Download</a>
          <?php else: ?>
          <span class="btn btn-outline btn-sm" style="cursor:not-allowed;opacity:.5">🔒 <?= htmlspecialchars($t['access_type']) ?> Only</span>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php endwhile; else: ?>
    <div class="empty" style="padding:60px;grid-column:1/-1"><div class="ico">📥</div><h3>No tools available yet</h3></div>
    <?php endif; ?>
    </div>
  </div>
</div></div>
<script src="../assets/script.js"></script>
</body></html>
