<?php
require_once '../config.php';
if (!is_admin()) redirect('../admin/login.php');
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        $title   = trim($_POST['title']);
        $content = trim($_POST['content']);
        $type    = $_POST['type'];
        $stmt = mysqli_prepare($conn,"INSERT INTO announcements (title,content,type,created_by) VALUES (?,?,?,?)");
        mysqli_stmt_bind_param($stmt,'ssss',$title,$content,$type,$_SESSION['admin_username']);
        mysqli_stmt_execute($stmt); mysqli_stmt_close($stmt);
        $msg = '✅ Announcement posted!';
    }
    if (isset($_POST['toggle_id'])) {
        $id=(int)$_POST['toggle_id'];
        mysqli_query($conn,"UPDATE announcements SET is_active=NOT is_active WHERE id=$id");
        $msg = '✅ Status updated.';
    }
    if (isset($_POST['delete_id'])) {
        $id=(int)$_POST['delete_id'];
        mysqli_query($conn,"DELETE FROM announcements WHERE id=$id");
        $msg = '✅ Deleted.';
    }
}
$rows = mysqli_query($conn,"SELECT * FROM announcements ORDER BY created_at DESC");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Announcements — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head><body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar"><div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">Admin / Messaging</div><div class="tb-title">Announcements</div></div></div>
    <div class="tb-right"><span class="tb-clock" id="clock"></span><div class="online-dot"></div></div>
  </div>
  <div class="content">
    <?php if ($msg): ?><div class="alert alert-ok"><?= h($msg) ?></div><?php endif; ?>
    <div class="page-hdr">
      <div><div class="page-title">📢 Announcements</div></div>
      <button class="btn btn-grad" onclick="openModal('addModal')">➕ New Announcement</button>
    </div>
    <div class="card fade-in">
      <div class="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Title</th><th>Type</th><th>Status</th><th>Posted</th><th>Actions</th></tr></thead>
          <tbody>
          <?php if(mysqli_num_rows($rows)): $n=1; while($r=mysqli_fetch_assoc($rows)): ?>
          <tr>
            <td style="color:var(--muted)"><?= $n++ ?></td>
            <td>
              <strong><?= h($r['title']) ?></strong>
              <div style="font-size:11px;color:var(--muted)"><?= h(substr($r['content'],0,70)) ?>...</div>
            </td>
            <td>
              <?php $tc=['info'=>'b-basic','warning'=>'b-used','success'=>'b-active','danger'=>'b-banned'];?>
              <span class="badge <?= $tc[$r['type']]??'b-basic' ?>"><?= strtoupper(h($r['type'])) ?></span>
            </td>
            <td><span class="badge <?= $r['is_active']?'b-active':'b-expired' ?>"><?= $r['is_active']?'Active':'Hidden' ?></span></td>
            <td style="font-size:12px;color:var(--muted)"><?= fmt_date($r['created_at']) ?></td>
            <td>
              <div style="display:flex;gap:5px">
                <form method="POST" style="display:inline">
                  <input type="hidden" name="toggle_id" value="<?= $r['id'] ?>">
                  <button class="btn btn-outline btn-sm"><?= $r['is_active']?'⏸️':'▶️' ?></button>
                </form>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="delete_id" value="<?= $r['id'] ?>">
                  <button class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endwhile; else: ?>
          <tr><td colspan="6"><div class="empty" style="padding:40px"><div class="ico">📢</div><h3>No announcements yet</h3></div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div></div>
<div class="modal-bg" id="addModal">
  <div class="modal">
    <div class="modal-hdr"><span class="modal-title">📢 NEW ANNOUNCEMENT</span><button class="modal-close" onclick="closeModal('addModal')">×</button></div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-group" style="margin-bottom:14px"><label>Title</label><input type="text" name="title" required></div>
        <div class="form-group" style="margin-bottom:14px"><label>Content</label><textarea name="content" rows="4" required></textarea></div>
        <div class="form-group"><label>Type</label>
          <select name="type"><option value="info">ℹ️ Info</option><option value="warning">⚠️ Warning</option><option value="success">✅ Success</option><option value="danger">🚨 Danger</option></select>
        </div>
      </div>
      <div class="modal-ftr">
        <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" name="add" class="btn btn-grad">📢 Post</button>
      </div>
    </form>
  </div>
</div>
<script src="../assets/script.js"></script>
</body></html>
