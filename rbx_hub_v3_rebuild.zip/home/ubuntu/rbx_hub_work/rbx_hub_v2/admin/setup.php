<?php
require_once '../config.php';
$ex = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM admins WHERE role='SUPER_ADMIN'"))['c']??0;
if ($ex > 0) die('<div style="font-family:monospace;color:#ef4444;text-align:center;padding:80px;background:#05050a;min-height:100vh;display:flex;align-items:center;justify-content:center"><div><h2>⚠️ Admin already exists!</h2><p style="margin-top:10px;color:#5a5a7a">Delete setup.php for security.</p></div></div>');
$msg=$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $u=clean_post('username'); $p=$_POST['password']??''; $c=$_POST['confirm']??''; $e=clean_post('email');
    if (!validate_username($u)) $err='Username: 4-50 chars, letters/numbers/underscore.';
    elseif (!validate_password($p)) $err='Password must be 6-100 characters.';
    elseif ($p!==$c) $err='Passwords do not match.';
    else {
        $h=password_hash($p,PASSWORD_DEFAULT);
        $stmt=mysqli_prepare($conn,"INSERT INTO admins (username,password,email,role,status) VALUES (?,?,?,'SUPER_ADMIN','ACTIVE')");
        mysqli_stmt_bind_param($stmt,'sss',$u,$h,$e);
        if (mysqli_stmt_execute($stmt)) $msg="✅ Admin '$u' created! <strong>Delete setup.php now.</strong>";
        else $err='Error: '.mysqli_error($conn);
    }
}
?><!DOCTYPE html><html><head><meta charset="UTF-8"><title>Setup — RBX Hub</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Syne:wght@800&display=swap" rel="stylesheet">
<style>*{box-sizing:border-box;margin:0;padding:0}body{background:#05050a;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:'Inter',sans-serif}
.box{width:430px;padding:44px;background:#0d0d18;border:1px solid rgba(124,58,237,.3);border-radius:18px;box-shadow:0 0 60px rgba(124,58,237,.1);position:relative;overflow:hidden}
.box::before{content:'';display:block;height:2px;background:linear-gradient(135deg,#7c3aed,#06b6d4);position:absolute;top:0;left:0;right:0}
h1{font-family:'Syne',sans-serif;font-size:24px;background:linear-gradient(135deg,#7c3aed,#06b6d4);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:6px}
p{text-align:center;font-size:12px;color:#5a5a7a;margin-bottom:24px}
label{display:block;font-size:11px;font-weight:600;color:#5a5a7a;text-transform:uppercase;letter-spacing:1px;margin:12px 0 6px}
input{width:100%;padding:10px 14px;background:rgba(0,0,0,.4);border:1px solid rgba(255,255,255,.08);border-radius:8px;color:#e0e0f0;font-size:13px;outline:none}
input:focus{border-color:#7c3aed;box-shadow:0 0 0 3px rgba(124,58,237,.15)}
button{width:100%;padding:13px;margin-top:20px;background:linear-gradient(135deg,#7c3aed,#06b6d4);color:#fff;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer}
.ok{color:#10b981;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.25);padding:10px 14px;border-radius:8px;margin-bottom:16px;font-size:13px}
.err{color:#ef4444;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.25);padding:10px 14px;border-radius:8px;margin-bottom:16px;font-size:13px}
.warn{color:#f59e0b;text-align:center;font-size:12px;margin-top:16px}
</style></head><body>
<div class="box">
<h1>⚙️ Initial Setup</h1><p>Create your Super Admin account</p>
<?php if($msg): ?><div class="ok"><?= $msg ?></div>
<a href="login.php" style="display:block;text-align:center;color:#7c3aed;margin-top:10px;text-decoration:none">→ Go to Admin Login</a>
<?php else: ?>
<?php if($err): ?><div class="err">❌ <?= h($err) ?></div><?php endif; ?>
<form method="POST">
<?= csrf_field() ?>
<label>Username</label><input name="username" minlength="4" required autofocus>
<label>Password (min 6)</label><input type="password" name="password" required>
<label>Confirm Password</label><input type="password" name="confirm" required>
<label>Email (optional)</label><input type="email" name="email">
<button>🚀 Create Super Admin</button>
</form>
<?php endif; ?>
<p class="warn">⚠️ Delete this file after setup!</p>
</div></body></html>
