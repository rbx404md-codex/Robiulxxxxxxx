<?php
require_once '../config.php';
if (!is_super()) redirect('dashboard.php');

$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add reseller
    if (isset($_POST['add_reseller'])) {
        $uname  = trim($_POST['username']);
        $pass   = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $email  = trim($_POST['email']);
        $stmt   = mysqli_prepare($conn,
            "INSERT INTO admins (username,password,email,role) VALUES (?,?,?,'RESELLER')");
        mysqli_stmt_bind_param($stmt,'sss',$uname,$pass,$email);
        if (mysqli_stmt_execute($stmt)) {
            log_activity('','RESELLER_ADDED',"Added: $uname");
            $msg = "✅ Reseller '$uname' added!";
        } else {
            $err = '❌ Username already exists.';
        }
    }
    // Ban/Unban
    if (isset($_POST['ban_id'])) {
        $id = (int)$_POST['ban_id'];
        mysqli_query($conn,"UPDATE admins SET status='BANNED' WHERE id=$id AND role='RESELLER'");
        $msg = '✅ Reseller banned.';
    }
    if (isset($_POST['unban_id'])) {
        $id = (int)$_POST['unban_id'];
        mysqli_query($conn,"UPDATE admins SET status='ACTIVE' WHERE id=$id AND role='RESELLER'");
        $msg = '✅ Reseller unbanned.';
    }
    // Delete
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        mysqli_query($conn,"DELETE FROM admins WHERE id=$id AND role='RESELLER'");
        $msg = '✅ Reseller deleted.';
    }
}

$resellers = mysqli_query($conn,
    "SELECT a.*,
     (SELECT COUNT(*) FROM licenses WHERE created_by=a.username) AS keys_created,
     (SELECT COUNT(*) FROM licenses WHERE created_by=a.username AND status='USED') AS keys_used
     FROM admins a WHERE a.role='RESELLER' ORDER BY a.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Resellers — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head>
<body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar">
    <div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">Admin / Resellers</div><div class="tb-title">Resellers</div></div></div>
    <div class="topbar-right">
      <span class="topbar-time" id="live-clock"></span>
      <span class="status-dot"></span>
    </div>
  </div>
  <div class="content">

    <?php if ($msg): ?><div class="alert alert-success fade-in"><?= h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-danger  fade-in"><?= h($err) ?></div><?php endif; ?>

    <div class="page-header">
      <div class="page-title">🤝 Reseller Management</div>
      <button class="btn btn-primary" onclick="openModal('addModal')">➕ Add Reseller</button>
    </div>

    <div class="card fade-in">
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>#</th><th>Username</th><th>Email</th>
            <th>Keys Created</th><th>Keys Sold</th>
            <th>Status</th><th>Last Login</th><th>Actions</th>
          </tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($resellers) > 0):
            $n = 1;
            while ($r = mysqli_fetch_assoc($resellers)):
              $sold_pct = $r['keys_created'] > 0
                ? round($r['keys_used']/$r['keys_created']*100) : 0;
          ?>
          <tr>
            <td style="color:var(--muted);font-size:12px;"><?= $n++ ?></td>
            <td>
              <strong style="color:var(--neon-yellow)"><?= h($r['username']) ?></strong>
            </td>
            <td style="font-size:13px;color:var(--muted);"><?= h($r['email'] ?? '—') ?></td>
            <td>
              <span style="color:var(--neon-blue);font-weight:700;"><?= $r['keys_created'] ?></span>
              <div class="commission-bar" style="width:80px;">
                <div class="commission-fill" style="width:<?= $sold_pct ?>%;background:var(--neon-blue);"></div>
              </div>
            </td>
            <td>
              <span style="color:var(--neon-green);font-weight:700;"><?= $r['keys_used'] ?></span>
              <span style="font-size:11px;color:var(--muted);"> (<?= $sold_pct ?>%)</span>
            </td>
            <td>
              <span class="badge badge-<?= strtolower($r['status']) ?>"><?= h($r['status']) ?></span>
            </td>
            <td style="font-size:12px;color:var(--muted);"><?= format_date($r['last_login']) ?></td>
            <td>
              <div style="display:flex;gap:6px;">
                <form method="POST" style="display:inline;">
                  <?php if ($r['status']==='BANNED'): ?>
                    <input type="hidden" name="unban_id" value="<?= $r['id'] ?>">
                    <button class="btn btn-outline btn-sm">✅ Unban</button>
                  <?php else: ?>
                    <input type="hidden" name="ban_id" value="<?= $r['id'] ?>">
                    <button class="btn btn-danger btn-sm" onclick="return confirm('Ban?')">🚫 Ban</button>
                  <?php endif; ?>
                </form>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="delete_id" value="<?= $r['id'] ?>">
                  <button class="btn btn-danger btn-sm" onclick="return confirm('Delete reseller?')">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endwhile; else: ?>
          <tr><td colspan="8"><div class="empty-state" style="padding:50px;">
            <div class="icon">🤝</div>
            <h3>No resellers yet</h3>
            <p style="margin-top:8px;font-size:13px;">Add resellers to let them sell licenses</p>
          </div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</div>
</div>

<!-- Add Reseller Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">🤝 ADD RESELLER</span>
      <button class="modal-close" onclick="closeModal('addModal')">×</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-group">
          <label>Username</label>
          <input type="text" name="username" required>
        </div>
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" minlength="6" required>
        </div>
        <div class="form-group">
          <label>Email (optional)</label>
          <input type="email" name="email">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" name="add_reseller" class="btn btn-primary">➕ Add</button>
      </div>
    </form>
  </div>
</div>

<script src="../assets/script.js"></script>
</body>
</html>
