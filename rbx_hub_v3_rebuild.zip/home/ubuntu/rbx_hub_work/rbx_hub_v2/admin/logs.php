<?php
require_once '../config.php';
if (!is_admin()) redirect('index.php');

// Export CSV
if (isset($_GET['export'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="logs_'.date('Y-m-d').'.csv"');
    $res = mysqli_query($conn, "SELECT * FROM activity_logs ORDER BY created_at DESC");
    echo "ID,Username,Admin,Action,Details,HWID,IP,Date\n";
    while ($r = mysqli_fetch_assoc($res)) {
        echo implode(',', array_map(fn($v) => '"'.str_replace('"','""',$v).'"', [
            $r['id'],$r['username'],$r['admin_name'],$r['action'],
            $r['details'],$r['hwid'],$r['ip_address'],$r['created_at']
        ])) . "\n";
    }
    exit();
}

// Clear logs (super admin only)
if (isset($_POST['clear_logs']) && is_super()) {
    mysqli_query($conn, "TRUNCATE TABLE activity_logs");
    $msg = '✅ All logs cleared.';
}

$search  = trim($_GET['q']      ?? '');
$filter  = $_GET['action']      ?? '';
$per_page = 30;
$page_num = max(1,(int)($_GET['p'] ?? 1));
$offset   = ($page_num-1)*$per_page;

$where = '1'; $params = []; $types = '';
if ($filter) { $where .= " AND action=?"; $types .= 's'; $params[] = $filter; }
if ($search) { $where .= " AND (username LIKE ? OR details LIKE ? OR ip_address LIKE ?)";
               $types .= 'sss'; $params[] = "%$search%"; $params[] = "%$search%"; $params[] = "%$search%"; }

$count_stmt = mysqli_prepare($conn, "SELECT COUNT(*) c FROM activity_logs WHERE $where");
if ($types) mysqli_stmt_bind_param($count_stmt, $types, ...$params);
mysqli_stmt_execute($count_stmt);
$total = mysqli_fetch_assoc(mysqli_stmt_get_result($count_stmt))['c'];
$pages = ceil($total / $per_page);

$stmt = mysqli_prepare($conn, "SELECT * FROM activity_logs WHERE $where ORDER BY created_at DESC LIMIT ? OFFSET ?");
$all = array_merge($params, [$per_page, $offset]);
mysqli_stmt_bind_param($stmt, $types.'ii', ...$all);
mysqli_stmt_execute($stmt);
$logs = mysqli_stmt_get_result($stmt);

$action_icons = [
    'LOGIN_SUCCESS'  => ['✅','badge-active'],
    'LOGIN_FAILED'   => ['❌','badge-banned'],
    'LOGIN_BANNED'   => ['🚫','badge-banned'],
    'LOGIN_EXPIRED'  => ['⏳','badge-expired'],
    'HWID_MISMATCH'  => ['⚠️','badge-used'],
    'REDEEM_SUCCESS' => ['🎉','badge-active'],
    'REDEEM_FAILED'  => ['💔','badge-banned'],
    'ADMIN_LOGIN'    => ['🔐','badge-unused'],
    'ADMIN_LOGOUT'   => ['👋','badge-expired'],
    'USER_BANNED'    => ['🔨','badge-banned'],
    'BULK_GENERATE'  => ['⚡','badge-unused'],
    'LICENSE_REVOKE' => ['🗑️','badge-expired'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Logs — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head>
<body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar">
    <div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">Admin / System</div><div class="tb-title">Activity Logs</div></div></div>
    <div class="topbar-right">
      <span class="topbar-time" id="live-clock"></span>
      <span class="status-dot"></span>
    </div>
  </div>
  <div class="content">

    <?php if (!empty($msg)): ?>
    <div class="alert alert-success fade-in"><?= h($msg) ?></div>
    <?php endif; ?>

    <div class="page-header">
      <div>
        <div class="page-title">📜 Activity Logs</div>
        <div class="page-subtitle">Total: <?= $total ?> records</div>
      </div>
      <div style="display:flex;gap:10px;">
        <a href="?export=1" class="btn btn-outline">📥 Export CSV</a>
        <?php if (is_super()): ?>
        <form method="POST" style="display:inline;">
          <button name="clear_logs" class="btn btn-danger"
            onclick="return confirm('Clear ALL logs? This cannot be undone!')">🗑️ Clear All</button>
        </form>
        <?php endif; ?>
      </div>
    </div>

    <div class="filter-bar">
      <input type="text" id="logSearch" placeholder="🔍 Username / IP / Details..."
             value="<?= h($search) ?>" oninput="liveSearch(this.value)">
      <select onchange="applyFilter('action',this.value)">
        <option value="">All Actions</option>
        <?php foreach (array_keys($action_icons) as $a): ?>
        <option value="<?= $a ?>" <?= $filter===$a?'selected':'' ?>><?= $a ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div class="card fade-in">
      <div class="table-wrap">
        <table id="logTable">
          <thead><tr>
            <th>#</th><th>Action</th><th>User</th>
            <th>Details</th><th>IP</th><th>HWID</th><th>Time</th>
          </tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($logs) > 0):
            $n = $offset + 1;
            while ($l = mysqli_fetch_assoc($logs)):
              [$icon, $badge] = $action_icons[$l['action']] ?? ['📝','badge-unused'];
          ?>
          <tr>
            <td style="color:var(--muted);font-size:12px;"><?= $n++ ?></td>
            <td>
              <span class="badge <?= $badge ?>" style="gap:6px;">
                <?= $icon ?> <?= h($l['action']) ?>
              </span>
            </td>
            <td>
              <span style="color:var(--neon-yellow);font-weight:700;"><?= h($l['username'] ?: $l['admin_name']) ?></span>
            </td>
            <td style="font-size:13px;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"
                title="<?= h($l['details']) ?>"><?= h($l['details']) ?></td>
            <td style="font-family:'Share Tech Mono',monospace;font-size:12px;color:var(--muted);"><?= h($l['ip_address']) ?></td>
            <td style="font-family:'Share Tech Mono',monospace;font-size:11px;color:var(--muted);">
              <?= $l['hwid'] ? substr(h($l['hwid']),0,12).'...' : '—' ?>
            </td>
            <td style="font-size:12px;color:var(--muted);white-space:nowrap;"><?= format_date($l['created_at']) ?></td>
          </tr>
          <?php endwhile; else: ?>
          <tr><td colspan="7"><div class="empty-state" style="padding:40px;">
            <div class="icon">📜</div><h3>No logs found</h3>
          </div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
      <?php if ($pages > 1): ?>
      <div class="pagination">
        <?php for ($i = 1; $i <= $pages; $i++): ?>
        <a href="?p=<?= $i ?>&action=<?= urlencode($filter) ?>&q=<?= urlencode($search) ?>"
           class="page-btn <?= $i===$page_num?'active':'' ?>"><?= $i ?></a>
        <?php endfor; ?>
        <span class="page-info"><?= $total ?> total</span>
      </div>
      <?php endif; ?>
    </div>

  </div>
</div>
</div>
<script src="../assets/script.js"></script>
<script>
function liveSearch(q) { searchTable('logSearch', 'logTable'); }
function applyFilter(key, val) {
  const url = new URL(location.href);
  url.searchParams.set(key, val);
  url.searchParams.set('p', 1);
  location.href = url;
}
</script>
</body>
</html>
