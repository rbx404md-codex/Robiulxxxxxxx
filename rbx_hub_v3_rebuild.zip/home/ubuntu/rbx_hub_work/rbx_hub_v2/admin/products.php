<?php
require_once '../config.php';
if (!is_admin()) redirect('index.php');

$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_product'])) {
        $name   = trim($_POST['product_name']);
        $type   = in_array($_POST['access_type'],['BASIC','PRO','ENTERPRISE']) ? $_POST['access_type'] : 'BASIC';
        $days   = max(1,(int)$_POST['duration_days']);
        $price  = (float)$_POST['price'];
        $rprice = (float)$_POST['reseller_price'];
        $feats  = trim($_POST['features']);
        $stmt = mysqli_prepare($conn,
            "INSERT INTO products (product_name,access_type,duration_days,price,reseller_price,features)
             VALUES (?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt,'ssidds',$name,$type,$days,$price,$rprice,$feats);
        mysqli_stmt_execute($stmt);
        $msg = '✅ Product added!';
    }
    if (isset($_POST['toggle_id'])) {
        $id = (int)$_POST['toggle_id'];
        mysqli_query($conn,"UPDATE products SET is_active = NOT is_active WHERE id=$id");
        $msg = '✅ Product status toggled.';
    }
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        mysqli_query($conn,"DELETE FROM products WHERE id=$id");
        $msg = '✅ Product deleted.';
    }
}

$products = mysqli_query($conn,"SELECT * FROM products ORDER BY sort_order, id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Products — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head>
<body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar">
    <div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">Admin / Catalog</div><div class="tb-title">Products</div></div></div>
    <div class="topbar-right">
      <span class="topbar-time" id="live-clock"></span>
      <span class="status-dot"></span>
    </div>
  </div>
  <div class="content">

    <?php if ($msg): ?><div class="alert alert-success fade-in"><?= h($msg) ?></div><?php endif; ?>

    <div class="page-header">
      <div class="page-title">📦 Product Pricing</div>
      <button class="btn btn-primary" onclick="openModal('addModal')">➕ Add Product</button>
    </div>

    <div class="card fade-in">
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th>#</th><th>Product Name</th><th>Type</th>
            <th>Duration</th><th>Price</th><th>Reseller Price</th>
            <th>Status</th><th>Actions</th>
          </tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($products) > 0):
            $n = 1;
            while ($p = mysqli_fetch_assoc($products)): ?>
          <tr>
            <td style="color:var(--muted);font-size:12px;"><?= $n++ ?></td>
            <td><strong><?= h($p['product_name']) ?></strong>
              <?php if ($p['features']): ?>
              <div style="font-size:11px;color:var(--muted);"><?= h($p['features']) ?></div>
              <?php endif; ?>
            </td>
            <td><span class="badge badge-<?= strtolower($p['access_type']) ?>"><?= h($p['access_type']) ?></span></td>
            <td><?= $p['duration_days'] >= 36500 ? '♾️ Lifetime' : h($p['duration_days']).'d' ?></td>
            <td style="color:var(--neon-yellow);font-weight:700;">৳<?= number_format($p['price'],0) ?></td>
            <td style="color:var(--neon-green);">৳<?= number_format($p['reseller_price'],0) ?></td>
            <td>
              <?php if ($p['is_active']): ?>
                <span class="badge badge-active">Active</span>
              <?php else: ?>
                <span class="badge badge-expired">Inactive</span>
              <?php endif; ?>
            </td>
            <td>
              <div style="display:flex;gap:6px;">
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="toggle_id" value="<?= $p['id'] ?>">
                  <button class="btn btn-outline btn-sm" title="Toggle"><?= $p['is_active']?'⏸️':'▶️' ?></button>
                </form>
                <form method="POST" style="display:inline;">
                  <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                  <button class="btn btn-danger btn-sm" onclick="return confirm('Delete?')">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endwhile; else: ?>
          <tr><td colspan="8"><div class="empty-state" style="padding:40px;">
            <div class="icon">📦</div><h3>No products yet</h3>
          </div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>

<!-- Add Product Modal -->
<div class="modal-overlay" id="addModal">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">➕ ADD PRODUCT</span>
      <button class="modal-close" onclick="closeModal('addModal')">×</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-group">
          <label>Product Name</label>
          <input type="text" name="product_name" placeholder="e.g. Garena Premium 30 Days" required>
        </div>
        <div class="grid-2">
          <div class="form-group">
            <label>Access Type</label>
            <select name="access_type">
              <option value="BASIC">🔵 BASIC</option>
              <option value="FULL">🟡 FULL</option>
              <option value="VIP">🟣 VIP</option>
            </select>
          </div>
          <div class="form-group">
            <label>Duration (days)</label>
            <input type="number" name="duration_days" value="30" min="1">
          </div>
        </div>
        <div class="grid-2">
          <div class="form-group">
            <label>Price (BDT)</label>
            <input type="number" name="price" value="0" min="0" step="0.01">
          </div>
          <div class="form-group">
            <label>Reseller Price</label>
            <input type="number" name="reseller_price" value="0" min="0" step="0.01">
          </div>
        </div>
        <div class="form-group">
          <label>Features (optional)</label>
          <input type="text" name="features" placeholder="e.g. All tools + Priority support">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" name="add_product" class="btn btn-primary">➕ Add</button>
      </div>
    </form>
  </div>
</div>

<script src="../assets/script.js"></script>
</body>
</html>
