<?php
require_once '../config.php';
if (is_admin()) log_activity($_SESSION['admin_username']??'','ADMIN_LOGOUT','');
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(),'',time()-3600,$p['path'],$p['domain'],$p['secure'],$p['httponly']);
}
session_destroy();
redirect('../admin/login.php');
