<?php
require_once '../config.php';
if (!is_admin()) redirect('../admin/login.php');

$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_tool'])) {
        $name    = trim($_POST['tool_name']);
        $ver     = trim($_POST['version']);
        $desc    = trim($_POST['description']);
        $type    = $_POST['access_type'];
        $dl_url  = trim($_POST['download_url']);
        $mandatory = isset($_POST['mandatory_update']) ? 1 : 0;
        $stmt = mysqli_prepare($conn,
            "INSERT INTO downloads (tool_name,version,description,access_type,download_url,mandatory_update,created_by)
             VALUES (?,?,?,?,?,?,?)");
        mysqli_stmt_bind_param($stmt,'sssssis',$name,$ver,$desc,$type,$dl_url,$mandatory,$_SESSION['admin_username']);
        if (mysqli_stmt_execute($stmt)) {
            log_activity('','TOOL_ADDED',"$name v$ver");
            $msg = "✅ Tool '$name' added!";
        } else {
            $err = '❌ Error: ' . mysqli_error($conn);
        }
        mysqli_stmt_close($stmt);
    }
    if (isset($_POST['toggle_id'])) {
        $id = (int)$_POST['toggle_id'];
        mysqli_query($conn,"UPDATE downloads SET is_active = NOT is_active WHERE id=$id");
        $msg = '✅ Visibility toggled.';
    }
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        mysqli_query($conn,"DELETE FROM downloads WHERE id=$id");
        $msg = '✅ Tool deleted.';
    }
}

$tools = mysqli_query($conn,"SELECT * FROM downloads ORDER BY created_at DESC");
?>
<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Downloads — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head><body>
<div class="wrapper">
<?php include 'includes/sidebar.php'; ?>
<div class="main">
  <div class="topbar">
    <div class="tb-left"><button class="sidebar-toggle" data-sidebar-toggle>☰</button><div><div class="breadcrumb">Admin / Distribution</div><div class="tb-title">Downloads</div></div></div>
    <div class="tb-right"><span class="tb-clock" id="clock"></span><div class="online-dot"></div></div>
  </div>
  <div class="content">
    <?php if ($msg): ?><div class="alert alert-ok fade-in"><?= h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="alert alert-err fade-in"><?= h($err) ?></div><?php endif; ?>
    <div class="page-hdr">
      <div><div class="page-title">📥 Tool Distribution</div><div class="page-sub">Upload and manage downloadable tools</div></div>
      <button class="btn btn-grad" onclick="openModal('addModal')">➕ Add Tool</button>
    </div>
    <div class="card fade-in">
      <div class="table-wrap">
        <table>
          <thead><tr><th>#</th><th>Tool Name</th><th>Version</th><th>Access</th><th>Downloads</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
          <?php if (mysqli_num_rows($tools)):
            $n=1; while ($t = mysqli_fetch_assoc($tools)): ?>
          <tr>
            <td style="color:var(--muted)"><?= $n++ ?></td>
            <td>
              <strong style="color:var(--a4)"><?= h($t['tool_name']) ?></strong>
              <?php if ($t['mandatory_update']): ?><span class="badge b-used" style="margin-left:6px">⚠️ MANDATORY</span><?php endif; ?>
              <div style="font-size:11px;color:var(--muted);margin-top:2px"><?= h(substr($t['description'],0,60)) ?></div>
            </td>
            <td><span style="font-family:'JetBrains Mono',monospace;color:var(--a2)"><?= h($t['version']) ?></span></td>
            <td><span class="badge b-<?= strtolower($t['access_type']) ?>"><?= h($t['access_type']) ?></span></td>
            <td style="color:var(--a3);font-weight:600"><?= $t['download_count'] ?></td>
            <td><span class="badge <?= $t['is_active'] ? 'b-active' : 'b-expired' ?>"><?= $t['is_active'] ? 'Active' : 'Hidden' ?></span></td>
            <td>
              <div style="display:flex;gap:5px">
                <form method="POST" style="display:inline">
                  <input type="hidden" name="toggle_id" value="<?= $t['id'] ?>">
                  <button class="btn btn-outline btn-sm"><?= $t['is_active']?'⏸️':'▶️' ?></button>
                </form>
                <form method="POST" style="display:inline">
                  <input type="hidden" name="delete_id" value="<?= $t['id'] ?>">
                  <button class="btn btn-danger btn-sm" onclick="return confirm('Delete tool?')">🗑️</button>
                </form>
              </div>
            </td>
          </tr>
          <?php endwhile; else: ?>
          <tr><td colspan="7"><div class="empty" style="padding:40px"><div class="ico">📥</div><h3>No tools uploaded yet</h3></div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div></div>

<div class="modal-bg" id="addModal">
  <div class="modal">
    <div class="modal-hdr"><span class="modal-title">➕ ADD TOOL</span><button class="modal-close" onclick="closeModal('addModal')">×</button></div>
    <form method="POST">
      <div class="modal-body">
        <div class="form-row col2">
          <div class="form-group"><label>Tool Name</label><input type="text" name="tool_name" required></div>
          <div class="form-group"><label>Version</label><input type="text" name="version" placeholder="1.0.0" required></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Description</label><input type="text" name="description"></div>
        </div>
        <div class="form-row col2">
          <div class="form-group"><label>Access Type</label>
            <select name="access_type">
              <option value="BASIC">Basic</option><option value="PRO">Pro</option><option value="ENTERPRISE">Enterprise</option>
            </select>
          </div>
          <div class="form-group"><label>Download URL</label><input type="text" name="download_url" placeholder="https://..."></div>
        </div>
        <div class="form-group">
          <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
            <input type="checkbox" name="mandatory_update" style="width:auto">
            Mark as Mandatory Update
          </label>
        </div>
      </div>
      <div class="modal-ftr">
        <button type="button" class="btn btn-outline" onclick="closeModal('addModal')">Cancel</button>
        <button type="submit" name="add_tool" class="btn btn-grad">➕ Add Tool</button>
      </div>
    </form>
  </div>
</div>

<script src="../assets/script.js"></script>
</body></html>
