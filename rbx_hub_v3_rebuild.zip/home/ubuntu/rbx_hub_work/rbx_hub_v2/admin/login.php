<?php
require_once '../config.php';
if (is_admin()) redirect('dashboard.php');
$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    // Rate limit: 5 attempts per 15 min
    if (!rate_limit_check('admin_login', 5, 900)) {
        $err = 'Too many attempts. Try again in 15 minutes.';
    } else {
        $u = clean_post('username'); $p = $_POST['password'] ?? '';
        if (!$u || !$p) { $err = 'All fields required.'; }
        else {
            $stmt = mysqli_prepare($conn,"SELECT * FROM admins WHERE username=? AND status='ACTIVE'");
            mysqli_stmt_bind_param($stmt,'s',$u); mysqli_stmt_execute($stmt);
            $a = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt)); mysqli_stmt_close($stmt);
            if ($a && password_verify($p,$a['password'])) {
                session_regenerate_id(true);
                $_SESSION['admin_id']       = $a['id'];
                $_SESSION['admin_username'] = $a['username'];
                $_SESSION['admin_role']     = $a['role'];
                rate_limit_reset('admin_login');
                mysqli_query($conn,"UPDATE admins SET last_login=NOW() WHERE id={$a['id']}");
                log_activity($a['username'],'ADMIN_LOGIN','Successful login');
                redirect('dashboard.php');
            } else {
                $err = 'Invalid username or password.';
                log_activity($u,'ADMIN_LOGIN_FAIL','Wrong credentials from '.get_ip());
            }
        }
    }
}
?><!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — <?= h(APP_NAME) ?></title>
<link rel="stylesheet" href="../assets/admin.css">
</head><body>
<div class="login-page">
  <div class="login-box fade-in">
    <div class="login-logo">
      <div class="login-brand">⚡ RBX Hub</div>
      <div class="login-sub">ADMIN PANEL v<?= APP_VER ?></div>
    </div>
    <?php if ($err): ?><div class="alert alert-err">⚠️ <?= h($err) ?></div><?php endif; ?>
    <form method="POST">
      <?= csrf_field() ?>
      <div class="form-group" style="margin-bottom:14px">
        <label>Username</label>
        <input type="text" name="username" placeholder="admin" autofocus required autocomplete="username">
      </div>
      <div class="form-group" style="margin-bottom:20px">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required autocomplete="current-password">
      </div>
      <button type="submit" class="btn btn-grad" style="width:100%;justify-content:center;padding:12px;border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">
        🔐 Sign In
      </button>
    </form>
    <div class="login-divider"><span>or</span></div>
    <a href="../user/login.php" class="btn btn-outline" style="width:100%;justify-content:center">👤 User Portal</a>
    <div style="text-align:center;margin-top:18px;font-size:11px;color:var(--muted)">
      <a href="../index.php" style="color:var(--a1);text-decoration:none">← Back to Home</a>
    </div>
  </div>
</div>
<script>document.querySelectorAll('.alert').forEach(a=>{setTimeout(()=>{a.style.opacity='0';setTimeout(()=>a.remove(),400)},4000)});</script>
</body></html>
