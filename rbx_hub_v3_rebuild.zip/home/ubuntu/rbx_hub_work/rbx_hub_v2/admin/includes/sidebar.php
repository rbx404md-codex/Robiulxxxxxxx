<?php
if (!is_admin()) redirect('../user/login.php');
$p = basename($_SERVER['PHP_SELF']);
$un = $_SESSION['admin_username'] ?? 'Admin';
$role = $_SESSION['admin_role'] ?? 'ADMIN';
$init = strtoupper(substr($un, 0, 1));
function count_value(string $sql): int { global $conn; $r = mysqli_fetch_assoc(mysqli_query($conn, $sql)); return (int)($r['c'] ?? 0); }
$users_c = count_value("SELECT COUNT(*) c FROM users");
$keys_c  = count_value("SELECT COUNT(*) c FROM licenses WHERE status='UNUSED'");
$logs_c  = count_value("SELECT COUNT(*) c FROM activity_logs WHERE DATE(created_at)=CURDATE()");
$items = [
  ['dashboard.php','🏠','Dashboard',''],
  ['users.php','👥','Users',$users_c],
  ['licenses.php','🔑','Licenses',$keys_c],
  ['products.php','📦','Products',''],
  ['downloads.php','⬇️','Downloads',''],
  ['announcements.php','📢','Announcements',''],
  ['reseller.php','🤝','Resellers','super'],
  ['logs.php','📋','Activity Logs',$logs_c],
  ['settings.php','⚙️','Settings',''],
];
?>
<aside class="sidebar" id="sidebar">
  <div class="sb-brand"><div class="sb-logo"><strong>RBX</strong> Hub</div><div class="sb-ver">Admin Control v<?= h(APP_VER) ?></div></div>
  <div class="sb-user"><div class="sb-avatar"><?= h($init) ?></div><div><div class="sb-name"><?= h($un) ?></div><div class="sb-role"><?= h($role) ?></div></div></div>
  <nav class="sb-nav">
    <div class="sb-label">Control</div>
    <?php foreach ($items as $it): if ($it[3] === 'super' && !is_super()) continue; ?>
      <a href="<?= h($it[0]) ?>" class="sb-item <?= $p === $it[0] ? 'active' : '' ?>" title="<?= h($it[2]) ?>">
        <span class="sb-icon"><?= $it[1] ?></span><span class="sb-text"><?= h($it[2]) ?></span>
        <?php if (is_numeric($it[3]) && (int)$it[3] > 0): ?><span class="sb-badge"><?= (int)$it[3] ?></span><?php endif; ?>
      </a>
    <?php endforeach; ?>
    <div class="sb-label">Preview</div>
    <a href="../index.php" target="_blank" class="sb-item"><span class="sb-icon">🌐</span><span class="sb-text">Landing Page</span></a>
  </nav>
  <div class="sb-footer"><a href="logout.php" class="sb-logout"><span class="sb-icon">🚪</span><span class="sb-text">Logout</span></a></div>
</aside>
